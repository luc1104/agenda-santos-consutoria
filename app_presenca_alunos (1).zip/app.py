
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date, timedelta

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///alunos.db'
app.config['SECRET_KEY'] = 'secretkey'
db = SQLAlchemy(app)

class Aluno(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    data_nascimento = db.Column(db.Date)
    email = db.Column(db.String(120))
    telefone = db.Column(db.String(20))
    telefone_emergencia = db.Column(db.String(20))
    observacoes = db.Column(db.Text)
    valor_mensal = db.Column(db.Float)
    qtd_atendimentos_mes = db.Column(db.Integer)
    academia = db.Column(db.String(100))
    data_pagamento = db.Column(db.Date)
    cobrança_por_data = db.Column(db.Boolean, default=False)
    ativo = db.Column(db.Boolean, default=True)
    ultima_cobranca = db.Column(db.Date, default=date.today)
    presencas = db.relationship('Presenca', backref='aluno', lazy=True)
    agendamentos = db.relationship('Agendamento', backref='aluno', lazy=True)

class Presenca(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    aluno_id = db.Column(db.Integer, db.ForeignKey('aluno.id'), nullable=False)
    data = db.Column(db.Date, default=date.today)

class Agendamento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    aluno_id = db.Column(db.Integer, db.ForeignKey('aluno.id'), nullable=False)
    data_hora = db.Column(db.DateTime)

@app.route('/')
def index():
    alunos = Aluno.query.all()
    return render_template('index.html', alunos=alunos)

@app.route('/agenda')
def agenda():
    hoje = date.today()
    inicio_semana = hoje - timedelta(days=hoje.weekday())
    fim_semana = inicio_semana + timedelta(days=6)
    agendamentos = Agendamento.query.filter(Agendamento.data_hora.between(inicio_semana, fim_semana)).all()
    return render_template('agenda.html', agendamentos=agendamentos, inicio=inicio_semana, fim=fim_semana)

@app.route('/dashboard')
def dashboard():
    alunos = Aluno.query.filter_by(ativo=True).all()
    hoje = date.today()
    total_receber = sum(a.valor_mensal for a in alunos if (not a.data_pagamento or a.data_pagamento.month != hoje.month))
    total_pago = sum(a.valor_mensal for a in alunos if a.data_pagamento and a.data_pagamento.month == hoje.month)
    total_mes = total_pago + total_receber
    return render_template('dashboard.html', alunos=alunos, total_pago=total_pago, total_receber=total_receber, total_mes=total_mes)

if __name__ == '__main__':
    app.run(debug=True)
